//
//  Settings.swift
//  ProyectoCafeAPp
//
//  Created by Rodolfo Castillo as Haffee Dev team Member on 31/10/14.
//  Copyright (c) 2014 Rodolfo Castillo as Haffee Dev team Member. All rights reserved.
//

import Foundation

import Foundation

class Settings {
    var root = "http://104.131.140.199"
    //var orders = "http://192.168.1.6/posts.json" para ver historial
    var verCafe = "http://104.131.140.199/posts/view/$.json"
    var creaCafe = "http://104.131.140.199/posts/add"
}