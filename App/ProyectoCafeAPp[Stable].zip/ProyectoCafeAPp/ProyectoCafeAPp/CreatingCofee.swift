//
//  CreatingCofee.swift
//  ProyectoCafeAPp
//
//  Created by Rodolfo Castillo as Haffee Dev team Member on 31/10/14.
//  Copyright (c) 2014 Rodolfo Castillo as Haffee Dev team Member. All rights reserved.
//

import Foundation

class CreatingCofee{
    let Intensidad: [String: String]
    let Azucar: [String: String]
    init(){
    Intensidad = ["1": "Ligero","2": "Normal","3": "Intenso", "4": "Levanta Muertos", "5": "IN-HUMANO!"]
    Azucar = ["1": "Sugar-Free","2": "Cucharadita","3": "Cubos", "4": "Sweet-Tooth", "5": "Hanzel y Gretel"]
    }
    func getDict(Dictionary<Int, String>)-> Dictionary<Int, String>{
        return Dictionary()
    }
    
}
