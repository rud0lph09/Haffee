//
//  LoaderView.swift
//  ProyectoCafeAPp
//
//  Created by Rodolfo Castillo as Haffee Dev team Member on 01/11/14.
//  Copyright (c) 2014 Rodolfo Castillo as Haffee Dev team Member. All rights reserved.
//

import UIKit
class LoaderView: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
